<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if booking_id is provided
if (!isset($_GET['booking_id'])) {
    header("Location: dashboard.php");
    exit();
}

$booking_id = (int)$_GET['booking_id'];

// Fetch booking details
$stmt = $conn->prepare("
    SELECT b.*, br.from_location, br.to_location, br.departure_time, br.date, r.price
    FROM bookings b
    JOIN bus_routes br ON b.bus_route_id = br.id
    JOIN routes r ON br.route_id = r.id
    WHERE b.id = ? AND b.user_id = ?
");
$stmt->execute([$booking_id, $_SESSION['user_id']]);
$booking = $stmt->fetch();

if (!$booking) {
    header("Location: dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Success - CoachConnect</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
        }
        .success-container {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 0 15px rgba(0,0,0,.1);
            margin-top: 2rem;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
            text-align: center;
        }
        .success-icon {
            font-size: 4rem;
            color: #28a745;
            margin-bottom: 1rem;
        }
        .booking-details {
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 10px;
            margin: 2rem 0;
        }
        .btn-primary {
            border-radius: 25px;
            padding: 10px 25px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="success-container">
            <div class="success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            
            <h2 class="mb-4">Booking Confirmed!</h2>
            <p class="lead">Thank you for choosing CoachConnect. Your booking has been confirmed.</p>

            <div class="booking-details">
                <h4 class="mb-3">Booking Details</h4>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>From:</strong> <?php echo htmlspecialchars($booking['from_location']); ?></p>
                        <p><strong>To:</strong> <?php echo htmlspecialchars($booking['to_location']); ?></p>
                        <p><strong>Date:</strong> <?php echo date('M d, Y', strtotime($booking['date'])); ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Departure Time:</strong> <?php echo date('h:i A', strtotime($booking['departure_time'])); ?></p>
                        <p><strong>Seat Number:</strong> <?php echo $booking['seat_number']; ?></p>
                        <p><strong>Price:</strong> $<?php echo number_format($booking['price'], 2); ?></p>
                    </div>
                </div>
            </div>

            <div class="mt-4">
                <a href="dashboard.php" class="btn btn-primary me-2">
                    <i class="fas fa-tachometer-alt"></i> Go to Dashboard
                </a>
                <a href="index.php" class="btn btn-outline-primary">
                    <i class="fas fa-home"></i> Back to Home
                </a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 