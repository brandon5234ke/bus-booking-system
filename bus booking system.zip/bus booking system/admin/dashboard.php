<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Handle bus addition
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_bus'])) {
    $bus_number = trim($_POST['bus_number']);
    $total_seats = (int)$_POST['total_seats'];
    $model = trim($_POST['model']);

    $stmt = $conn->prepare("INSERT INTO buses (bus_number, total_seats, model) VALUES (?, ?, ?)");
    $stmt->execute([$bus_number, $total_seats, $model]);
}

// Handle route addition
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_route'])) {
    $from_location = trim($_POST['from_location']);
    $to_location = trim($_POST['to_location']);
    $departure_time = $_POST['departure_time'];
    $arrival_time = $_POST['arrival_time'];
    $price = (float)$_POST['price'];

    $stmt = $conn->prepare("INSERT INTO routes (from_location, to_location, departure_time, arrival_time, price) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$from_location, $to_location, $departure_time, $arrival_time, $price]);
}

// Fetch buses
$buses = $conn->query("SELECT * FROM buses ORDER BY created_at DESC")->fetchAll();

// Fetch routes
$routes = $conn->query("SELECT * FROM routes ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - CoachConnect</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
        }
        .sidebar {
            background: #2c3e50;
            min-height: 100vh;
            color: white;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,.8);
            padding: 1rem;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover {
            color: white;
            background: rgba(255,255,255,.1);
        }
        .sidebar .nav-link.active {
            background: rgba(255,255,255,.2);
        }
        .main-content {
            padding: 2rem;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0,0,0,.1);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="p-3">
                    <h4><i class="fas fa-bus"></i> CoachConnect</h4>
                    <hr>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#buses">
                                <i class="fas fa-bus"></i> Buses
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#routes">
                                <i class="fas fa-route"></i> Routes
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#bookings">
                                <i class="fas fa-ticket-alt"></i> Bookings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <h2 class="mb-4">Admin Dashboard</h2>
                
                <!-- Add Bus Form -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Add New Bus</h5>
                        <form method="POST" class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Bus Number</label>
                                <input type="text" class="form-control" name="bus_number" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Total Seats</label>
                                <input type="number" class="form-control" name="total_seats" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Model</label>
                                <input type="text" class="form-control" name="model" required>
                            </div>
                            <div class="col-12">
                                <button type="submit" name="add_bus" class="btn btn-primary">
                                    <i class="fas fa-plus"></i> Add Bus
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Add Route Form -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Add New Route</h5>
                        <form method="POST" class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">From Location</label>
                                <input type="text" class="form-control" name="from_location" required>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">To Location</label>
                                <input type="text" class="form-control" name="to_location" required>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Departure Time</label>
                                <input type="time" class="form-control" name="departure_time" required>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Arrival Time</label>
                                <input type="time" class="form-control" name="arrival_time" required>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Price</label>
                                <input type="number" step="0.01" class="form-control" name="price" required>
                            </div>
                            <div class="col-12">
                                <button type="submit" name="add_route" class="btn btn-primary">
                                    <i class="fas fa-plus"></i> Add Route
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Buses List -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Buses</h5>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Bus Number</th>
                                        <th>Model</th>
                                        <th>Total Seats</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($buses as $bus): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($bus['bus_number']); ?></td>
                                        <td><?php echo htmlspecialchars($bus['model']); ?></td>
                                        <td><?php echo $bus['total_seats']; ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $bus['status'] == 'active' ? 'success' : 'warning'; ?>">
                                                <?php echo ucfirst($bus['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Routes List -->
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Routes</h5>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>From</th>
                                        <th>To</th>
                                        <th>Departure</th>
                                        <th>Arrival</th>
                                        <th>Price</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($routes as $route): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($route['from_location']); ?></td>
                                        <td><?php echo htmlspecialchars($route['to_location']); ?></td>
                                        <td><?php echo date('h:i A', strtotime($route['departure_time'])); ?></td>
                                        <td><?php echo date('h:i A', strtotime($route['arrival_time'])); ?></td>
                                        <td>$<?php echo number_format($route['price'], 2); ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 