<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch user's bookings
$stmt = $conn->prepare("
    SELECT b.*, br.from_location, br.to_location, br.departure_time, br.arrival_time, br.price
    FROM bookings b
    JOIN bus_routes br ON b.bus_route_id = br.id
    WHERE b.user_id = ?
    ORDER BY b.booking_date DESC
");
$stmt->execute([$_SESSION['user_id']]);
$bookings = $stmt->fetchAll();

// Fetch available routes
$routes = $conn->query("SELECT * FROM routes ORDER BY from_location, to_location")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - CoachConnect</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
        }
        .sidebar {
            background: #2c3e50;
            min-height: 100vh;
            color: white;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,.8);
            padding: 1rem;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover {
            color: white;
            background: rgba(255,255,255,.1);
        }
        .sidebar .nav-link.active {
            background: rgba(255,255,255,.2);
        }
        .main-content {
            padding: 2rem;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0,0,0,.1);
        }
        #seat-container {
            width: 100%;
            height: 400px;
            background: #fff;
            border-radius: 15px;
            overflow: hidden;
        }
        .seat {
            width: 40px;
            height: 40px;
            margin: 5px;
            display: inline-block;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
            background: #e9ecef;
        }
        .seat:hover {
            transform: scale(1.1);
        }
        .seat.selected {
            background: #28a745;
        }
        .seat.booked {
            background: #dc3545;
            cursor: not-allowed;
        }
        .seat-number {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="p-3">
                    <h4><i class="fas fa-bus"></i> CoachConnect</h4>
                    <hr>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#bookings">
                                <i class="fas fa-ticket-alt"></i> My Bookings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#ratings">
                                <i class="fas fa-star"></i> My Ratings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <h2 class="mb-4">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>

                <!-- Book a Ticket -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Book a Ticket</h5>
                        <form id="booking-form" class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">From</label>
                                <select class="form-select" name="from" required>
                                    <option value="">Select departure</option>
                                    <?php foreach ($routes as $route): ?>
                                        <option value="<?php echo $route['id']; ?>">
                                            <?php echo htmlspecialchars($route['from_location']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">To</label>
                                <select class="form-select" name="to" required>
                                    <option value="">Select destination</option>
                                    <?php foreach ($routes as $route): ?>
                                        <option value="<?php echo $route['id']; ?>">
                                            <?php echo htmlspecialchars($route['to_location']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Date</label>
                                <input type="date" class="form-control" name="date" required>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search"></i> Search Buses
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- 3D Seat Selection -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Select Your Seat</h5>
                        <div id="seat-container">
                            <!-- Seats will be dynamically generated here -->
                        </div>
                        <div class="mt-3">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <span class="badge bg-success me-2">Selected</span>
                                    <span class="badge bg-danger me-2">Booked</span>
                                    <span class="badge bg-secondary">Available</span>
                                </div>
                                <div>
                                    <span class="me-3">Selected Seats: <span id="selected-seats">0</span></span>
                                    <span>Total Price: $<span id="total-price">0.00</span></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- My Bookings -->
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">My Bookings</h5>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>From</th>
                                        <th>To</th>
                                        <th>Date</th>
                                        <th>Seat</th>
                                        <th>Price</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($bookings as $booking): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($booking['from_location']); ?></td>
                                        <td><?php echo htmlspecialchars($booking['to_location']); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($booking['booking_date'])); ?></td>
                                        <td><?php echo $booking['seat_number']; ?></td>
                                        <td>$<?php echo number_format($booking['price'], 2); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $booking['status'] == 'confirmed' ? 'success' : 'warning'; ?>">
                                                <?php echo ucfirst($booking['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-primary">
                                                <i class="fas fa-ticket-alt"></i> View Ticket
                                            </button>
                                            <?php if ($booking['status'] == 'pending'): ?>
                                                <button class="btn btn-sm btn-danger">
                                                    <i class="fas fa-times"></i> Cancel
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script>
        // Initialize Three.js scene
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer();
        renderer.setSize(document.getElementById('seat-container').clientWidth, document.getElementById('seat-container').clientHeight);
        document.getElementById('seat-container').appendChild(renderer.domElement);

        // Create bus seats
        const seats = [];
        const seatGeometry = new THREE.BoxGeometry(1, 1, 1);
        const seatMaterial = new THREE.MeshPhongMaterial({ color: 0x808080 });
        
        // Create 4x10 grid of seats
        for (let row = 0; row < 4; row++) {
            for (let col = 0; col < 10; col++) {
                const seat = new THREE.Mesh(seatGeometry, seatMaterial);
                seat.position.set(col * 1.2 - 5, row * 1.2 - 1.5, 0);
                seat.userData.seatNumber = row * 10 + col + 1;
                seats.push(seat);
                scene.add(seat);
            }
        }

        // Add lighting
        const light = new THREE.DirectionalLight(0xffffff, 1);
        light.position.set(5, 5, 5);
        scene.add(light);
        scene.add(new THREE.AmbientLight(0x404040));

        // Position camera
        camera.position.z = 15;

        // Animation loop
        function animate() {
            requestAnimationFrame(animate);
            renderer.render(scene, camera);
        }
        animate();

        // Handle window resize
        window.addEventListener('resize', onWindowResize, false);
        function onWindowResize() {
            camera.aspect = document.getElementById('seat-container').clientWidth / document.getElementById('seat-container').clientHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(document.getElementById('seat-container').clientWidth, document.getElementById('seat-container').clientHeight);
        }

        // Handle seat selection
        const raycaster = new THREE.Raycaster();
        const mouse = new THREE.Vector2();
        let selectedSeats = new Set();

        document.getElementById('seat-container').addEventListener('click', onSeatClick, false);
        function onSeatClick(event) {
            const rect = renderer.domElement.getBoundingClientRect();
            mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

            raycaster.setFromCamera(mouse, camera);
            const intersects = raycaster.intersectObjects(scene.children);

            if (intersects.length > 0) {
                const seat = intersects[0].object;
                if (seat.userData.seatNumber) {
                    toggleSeat(seat);
                }
            }
        }

        function toggleSeat(seat) {
            const seatNumber = seat.userData.seatNumber;
            if (selectedSeats.has(seatNumber)) {
                selectedSeats.delete(seatNumber);
                seat.material.color.setHex(0x808080);
            } else {
                selectedSeats.add(seatNumber);
                seat.material.color.setHex(0x00ff00);
            }
            updateBookingSummary();
        }

        function updateBookingSummary() {
            document.getElementById('selected-seats').textContent = selectedSeats.size;
            // Update total price based on selected seats and route price
            const pricePerSeat = 50; // This should come from the selected route
            document.getElementById('total-price').textContent = (selectedSeats.size * pricePerSeat).toFixed(2);
        }
    </script>
</body>
</html> 