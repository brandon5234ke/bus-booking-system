<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if booking_id is provided
if (!isset($_GET['booking_id'])) {
    header("Location: dashboard.php");
    exit();
}

$booking_id = (int)$_GET['booking_id'];

// Fetch booking details
$stmt = $conn->prepare("
    SELECT b.*, br.from_location, br.to_location, br.departure_time, br.date, r.price
    FROM bookings b
    JOIN bus_routes br ON b.bus_route_id = br.id
    JOIN routes r ON br.route_id = r.id
    WHERE b.id = ? AND b.user_id = ?
");
$stmt->execute([$booking_id, $_SESSION['user_id']]);
$booking = $stmt->fetch();

if (!$booking) {
    header("Location: dashboard.php");
    exit();
}

// Handle payment submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['process_payment'])) {
    try {
        $conn->beginTransaction();
        
        // Update booking status
        $stmt = $conn->prepare("UPDATE bookings SET status = 'confirmed' WHERE id = ?");
        $stmt->execute([$booking_id]);
        
        $conn->commit();
        
        // Redirect to success page
        header("Location: booking_success.php?booking_id=" . $booking_id);
        exit();
    } catch (Exception $e) {
        $conn->rollBack();
        $error = "Payment processing failed. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - CoachConnect</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
        }
        .payment-container {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 0 15px rgba(0,0,0,.1);
            margin-top: 2rem;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }
        .booking-summary {
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 10px;
            margin-bottom: 2rem;
        }
        .payment-form {
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 10px;
        }
        .form-control {
            border-radius: 25px;
            padding: 10px 20px;
        }
        .btn-primary {
            border-radius: 25px;
            padding: 10px 25px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="payment-container">
            <h2 class="mb-4">
                <i class="fas fa-bus"></i> CoachConnect
            </h2>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <!-- Booking Summary -->
            <div class="booking-summary">
                <h4 class="mb-3">Booking Summary</h4>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>From:</strong> <?php echo htmlspecialchars($booking['from_location']); ?></p>
                        <p><strong>To:</strong> <?php echo htmlspecialchars($booking['to_location']); ?></p>
                        <p><strong>Date:</strong> <?php echo date('M d, Y', strtotime($booking['date'])); ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Departure Time:</strong> <?php echo date('h:i A', strtotime($booking['departure_time'])); ?></p>
                        <p><strong>Seat Number:</strong> <?php echo $booking['seat_number']; ?></p>
                        <p><strong>Price:</strong> $<?php echo number_format($booking['price'], 2); ?></p>
                    </div>
                </div>
            </div>

            <!-- Payment Form -->
            <div class="payment-form">
                <h4 class="mb-3">Payment Details</h4>
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Card Number</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-credit-card"></i></span>
                            <input type="text" class="form-control" placeholder="1234 5678 9012 3456" required>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Expiry Date</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                                <input type="text" class="form-control" placeholder="MM/YY" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">CVV</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                <input type="text" class="form-control" placeholder="123" required>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Cardholder Name</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="text" class="form-control" required>
                        </div>
                    </div>
                    <div class="d-grid">
                        <button type="submit" name="process_payment" class="btn btn-primary">
                            <i class="fas fa-lock"></i> Pay $<?php echo number_format($booking['price'], 2); ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 