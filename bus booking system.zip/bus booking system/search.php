<?php
session_start();
require_once 'config/database.php';

$from = isset($_GET['from']) ? trim($_GET['from']) : '';
$to = isset($_GET['to']) ? trim($_GET['to']) : '';
$date = isset($_GET['date']) ? $_GET['date'] : '';

$available_buses = [];

if ($from && $to && $date) {
    $stmt = $conn->prepare("
        SELECT br.*, b.bus_number, b.model, b.total_seats, r.from_location, r.to_location, r.departure_time, r.arrival_time, r.price
        FROM bus_routes br
        JOIN buses b ON br.bus_id = b.id
        JOIN routes r ON br.route_id = r.id
        WHERE r.from_location LIKE ? AND r.to_location LIKE ? AND br.date = ?
        AND br.available_seats > 0
        ORDER BY r.departure_time
    ");
    $stmt->execute(["%$from%", "%$to%", $date]);
    $available_buses = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Buses - CoachConnect</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
        }
        .search-container {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 0 15px rgba(0,0,0,.1);
            margin-top: 2rem;
        }
        .bus-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 0 10px rgba(0,0,0,.1);
            transition: transform 0.3s;
        }
        .bus-card:hover {
            transform: translateY(-5px);
        }
        .time-badge {
            background: #e9ecef;
            padding: 0.5rem 1rem;
            border-radius: 25px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="search-container">
            <h2 class="mb-4">
                <i class="fas fa-bus"></i> CoachConnect
            </h2>
            
            <!-- Search Form -->
            <form method="GET" class="row g-3 mb-4">
                <div class="col-md-4">
                    <label class="form-label">From</label>
                    <input type="text" class="form-control" name="from" value="<?php echo htmlspecialchars($from); ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">To</label>
                    <input type="text" class="form-control" name="to" value="<?php echo htmlspecialchars($to); ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Date</label>
                    <input type="date" class="form-control" name="date" value="<?php echo $date; ?>" required>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i> Search Buses
                    </button>
                </div>
            </form>

            <!-- Results -->
            <?php if ($from && $to && $date): ?>
                <h4 class="mb-4">Available Buses</h4>
                
                <?php if (empty($available_buses)): ?>
                    <div class="alert alert-info">
                        No buses available for the selected route and date.
                    </div>
                <?php else: ?>
                    <?php foreach ($available_buses as $bus): ?>
                        <div class="bus-card">
                            <div class="row align-items-center">
                                <div class="col-md-3">
                                    <h5>Bus <?php echo htmlspecialchars($bus['bus_number']); ?></h5>
                                    <p class="text-muted"><?php echo htmlspecialchars($bus['model']); ?></p>
                                </div>
                                <div class="col-md-3">
                                    <div class="time-badge">
                                        <i class="fas fa-clock"></i> <?php echo date('h:i A', strtotime($bus['departure_time'])); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <p class="mb-0">
                                        <i class="fas fa-chair"></i> Available Seats: <?php echo $bus['available_seats']; ?>
                                    </p>
                                    <p class="mb-0">
                                        <i class="fas fa-dollar-sign"></i> Price: $<?php echo number_format($bus['price'], 2); ?>
                                    </p>
                                </div>
                                <div class="col-md-3 text-end">
                                    <?php if (isset($_SESSION['user_id'])): ?>
                                        <a href="book.php?bus_route_id=<?php echo $bus['id']; ?>" class="btn btn-primary">
                                            <i class="fas fa-ticket-alt"></i> Book Now
                                        </a>
                                    <?php else: ?>
                                        <a href="login.php" class="btn btn-primary">
                                            <i class="fas fa-sign-in-alt"></i> Login to Book
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 