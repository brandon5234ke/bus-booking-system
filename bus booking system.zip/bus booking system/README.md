# CoachConnect - 3D Bus Booking System

A modern 3D bus ticketing and booking system built with PHP, featuring user authentication, admin dashboard, and interactive seat selection.

## Features
- User Authentication (Login/Signup)
- Admin Dashboard for Bus Management
- 3D Interactive Seat Selection
- User Rating System
- Modern UI/UX Design

## Requirements
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web Server (Apache/Nginx)
- Modern Web Browser with WebGL support

## Setup Instructions
1. Clone this repository
2. Import the database schema from `database/coachconnect.sql`
3. Configure your database connection in `config/database.php`
4. Set up your web server to point to the project directory
5. Access the application through your web browser

## Copyright
© 2024 Brandy Tech Solution. All rights reserved. 