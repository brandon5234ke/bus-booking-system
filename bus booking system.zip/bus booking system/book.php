<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if bus_route_id is provided
if (!isset($_GET['bus_route_id'])) {
    header("Location: search.php");
    exit();
}

$bus_route_id = (int)$_GET['bus_route_id'];

// Fetch bus route details
$stmt = $conn->prepare("
    SELECT br.*, b.bus_number, b.model, b.total_seats, r.from_location, r.to_location, r.departure_time, r.arrival_time, r.price
    FROM bus_routes br
    JOIN buses b ON br.bus_id = b.id
    JOIN routes r ON br.route_id = r.id
    WHERE br.id = ?
");
$stmt->execute([$bus_route_id]);
$bus_route = $stmt->fetch();

if (!$bus_route) {
    header("Location: search.php");
    exit();
}

// Handle booking submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['book_seats'])) {
    $selected_seats = $_POST['selected_seats'];
    $total_price = count($selected_seats) * $bus_route['price'];
    
    try {
        $conn->beginTransaction();
        
        // Insert booking
        $stmt = $conn->prepare("
            INSERT INTO bookings (user_id, bus_route_id, seat_number, status)
            VALUES (?, ?, ?, 'pending')
        ");
        
        foreach ($selected_seats as $seat_number) {
            $stmt->execute([$_SESSION['user_id'], $bus_route_id, $seat_number]);
        }
        
        // Update available seats
        $stmt = $conn->prepare("
            UPDATE bus_routes 
            SET available_seats = available_seats - ? 
            WHERE id = ?
        ");
        $stmt->execute([count($selected_seats), $bus_route_id]);
        
        $conn->commit();
        
        // Redirect to payment page or show success message
        header("Location: payment.php?booking_id=" . $conn->lastInsertId());
        exit();
    } catch (Exception $e) {
        $conn->rollBack();
        $error = "Booking failed. Please try again.";
    }
}

// Fetch booked seats
$stmt = $conn->prepare("SELECT seat_number FROM bookings WHERE bus_route_id = ?");
$stmt->execute([$bus_route_id]);
$booked_seats = $stmt->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Seats - CoachConnect</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
        }
        .booking-container {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 0 15px rgba(0,0,0,.1);
            margin-top: 2rem;
        }
        #seat-container {
            width: 100%;
            height: 400px;
            background: #fff;
            border-radius: 15px;
            overflow: hidden;
            margin: 2rem 0;
        }
        .seat {
            width: 40px;
            height: 40px;
            margin: 5px;
            display: inline-block;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
            background: #e9ecef;
        }
        .seat:hover {
            transform: scale(1.1);
        }
        .seat.selected {
            background: #28a745;
        }
        .seat.booked {
            background: #dc3545;
            cursor: not-allowed;
        }
        .seat-number {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            font-size: 12px;
        }
        .route-info {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="booking-container">
            <h2 class="mb-4">
                <i class="fas fa-bus"></i> CoachConnect
            </h2>

            <!-- Route Information -->
            <div class="route-info">
                <div class="row">
                    <div class="col-md-4">
                        <h5>From</h5>
                        <p><?php echo htmlspecialchars($bus_route['from_location']); ?></p>
                    </div>
                    <div class="col-md-4">
                        <h5>To</h5>
                        <p><?php echo htmlspecialchars($bus_route['to_location']); ?></p>
                    </div>
                    <div class="col-md-4">
                        <h5>Date & Time</h5>
                        <p>
                            <?php echo date('M d, Y', strtotime($bus_route['date'])); ?><br>
                            <?php echo date('h:i A', strtotime($bus_route['departure_time'])); ?>
                        </p>
                    </div>
                </div>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <!-- 3D Seat Selection -->
            <form method="POST" id="booking-form">
                <h4>Select Your Seats</h4>
                <div id="seat-container">
                    <!-- Seats will be dynamically generated here -->
                </div>
                
                <div class="mt-3">
                    <div class="d-flex justify-content-between">
                        <div>
                            <span class="badge bg-success me-2">Selected</span>
                            <span class="badge bg-danger me-2">Booked</span>
                            <span class="badge bg-secondary">Available</span>
                        </div>
                        <div>
                            <span class="me-3">Selected Seats: <span id="selected-seats">0</span></span>
                            <span>Total Price: $<span id="total-price">0.00</span></span>
                        </div>
                    </div>
                </div>

                <input type="hidden" name="selected_seats" id="selected-seats-input">
                
                <div class="mt-4">
                    <button type="submit" name="book_seats" class="btn btn-primary btn-lg" id="book-button" disabled>
                        <i class="fas fa-ticket-alt"></i> Proceed to Payment
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script>
        // Initialize Three.js scene
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer();
        renderer.setSize(document.getElementById('seat-container').clientWidth, document.getElementById('seat-container').clientHeight);
        document.getElementById('seat-container').appendChild(renderer.domElement);

        // Create bus seats
        const seats = [];
        const seatGeometry = new THREE.BoxGeometry(1, 1, 1);
        const seatMaterial = new THREE.MeshPhongMaterial({ color: 0x808080 });
        
        // Create 4x10 grid of seats
        for (let row = 0; row < 4; row++) {
            for (let col = 0; col < 10; col++) {
                const seat = new THREE.Mesh(seatGeometry, seatMaterial);
                seat.position.set(col * 1.2 - 5, row * 1.2 - 1.5, 0);
                seat.userData.seatNumber = row * 10 + col + 1;
                seats.push(seat);
                scene.add(seat);
            }
        }

        // Add lighting
        const light = new THREE.DirectionalLight(0xffffff, 1);
        light.position.set(5, 5, 5);
        scene.add(light);
        scene.add(new THREE.AmbientLight(0x404040));

        // Position camera
        camera.position.z = 15;

        // Animation loop
        function animate() {
            requestAnimationFrame(animate);
            renderer.render(scene, camera);
        }
        animate();

        // Handle window resize
        window.addEventListener('resize', onWindowResize, false);
        function onWindowResize() {
            camera.aspect = document.getElementById('seat-container').clientWidth / document.getElementById('seat-container').clientHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(document.getElementById('seat-container').clientWidth, document.getElementById('seat-container').clientHeight);
        }

        // Handle seat selection
        const raycaster = new THREE.Raycaster();
        const mouse = new THREE.Vector2();
        let selectedSeats = new Set();

        document.getElementById('seat-container').addEventListener('click', onSeatClick, false);
        function onSeatClick(event) {
            const rect = renderer.domElement.getBoundingClientRect();
            mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

            raycaster.setFromCamera(mouse, camera);
            const intersects = raycaster.intersectObjects(scene.children);

            if (intersects.length > 0) {
                const seat = intersects[0].object;
                if (seat.userData.seatNumber) {
                    toggleSeat(seat);
                }
            }
        }

        function toggleSeat(seat) {
            const seatNumber = seat.userData.seatNumber;
            if (selectedSeats.has(seatNumber)) {
                selectedSeats.delete(seatNumber);
                seat.material.color.setHex(0x808080);
            } else {
                selectedSeats.add(seatNumber);
                seat.material.color.setHex(0x00ff00);
            }
            updateBookingSummary();
        }

        function updateBookingSummary() {
            document.getElementById('selected-seats').textContent = selectedSeats.size;
            const pricePerSeat = <?php echo $bus_route['price']; ?>;
            const totalPrice = selectedSeats.size * pricePerSeat;
            document.getElementById('total-price').textContent = totalPrice.toFixed(2);
            
            // Update hidden input and enable/disable book button
            document.getElementById('selected-seats-input').value = Array.from(selectedSeats);
            document.getElementById('book-button').disabled = selectedSeats.size === 0;
        }

        // Mark booked seats
        const bookedSeats = <?php echo json_encode($booked_seats); ?>;
        bookedSeats.forEach(seatNumber => {
            const seat = seats.find(s => s.userData.seatNumber === seatNumber);
            if (seat) {
                seat.material.color.setHex(0xdc3545);
            }
        });
    </script>
</body>
</html> 